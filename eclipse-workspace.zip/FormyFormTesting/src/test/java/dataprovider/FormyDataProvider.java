package dataprovider;

import org.testng.annotations.DataProvider;

public class FormyDataProvider {
	
	@DataProvider(name = "firstNames")
	public Object[][] getFirstName(){
		return new Object[][] {
			{"Shivanath"},
			{"Ashish"}
		};
	}
	
	@DataProvider(name = "lastNames")
	public Object[][] getLastName(){
		return new Object[][] {
			{"Dursheti"},
			{"Chanchlani"}
		};
	}
	
	@DataProvider(name = "dates")
	public Object[][] getDates(){
		return new Object[][] {
			{"05/25/2002"},
			{"02/22/2002"}
		};
	}
	
}