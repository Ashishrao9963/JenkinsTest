package test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.epm.webdriver.WebDriverSingleton;

import dataprovider.FormyDataProvider;
import page.Formy;

public class FormyTesting {
	
	WebDriver driver;
	WebDriverSingleton webDriver = new WebDriverSingleton();
	Formy formy;
	
	@BeforeTest(alwaysRun = true)
	public void setupBrowser() {
		this.driver = webDriver.getWebDriver("chromedriver");
		formy = new Formy(driver);
		formy.launchFormyFormPage();
	}
	
	@Test(groups = {"smoke"})
	public void verifyFormyLogoIsDisplayed() {
		Assert.assertTrue(formy.isLogoDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyFirstNameIsDisplayed() {
		Assert.assertTrue(formy.isFirstNameDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyLastNameIsDisplayed() {
		Assert.assertTrue(formy.isLastNameDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyJobTitleIsDisplayed() {
		Assert.assertTrue(formy.isJobTitleDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyHighSchoolIsClickable() {
		Assert.assertTrue(formy.isRadioButton1Displayed());
	}
	@Test(groups = {"smoke"})
	public void verifyCollegeIsClickable() {
		Assert.assertTrue(formy.isRadioButton2Displayed());
	}
	@Test(groups = {"smoke"})
	public void verifyGradSchoolIsClickable() {
		Assert.assertTrue(formy.isRadioButton3Displayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyMaleGenderIsClickable() {
		Assert.assertTrue(formy.isCheckbox1Displayed());
	}
	@Test(groups = {"smoke"})
	public void verifyFemaleGenderIsClickable() {
		Assert.assertTrue(formy.isCheckbox2Displayed());
	}
	@Test(groups = {"smoke"})
	public void verifyPreferNotToSayIsClickable() {
		Assert.assertTrue(formy.isCheckbox3Displayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyYearsOfExperienceIsDisplayed() {
		Assert.assertTrue(formy.isFirstOptionDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifyDateIsDisplayed() {
		Assert.assertTrue(formy.isDateDisplayed());
	}
	
	@Test(groups = {"smoke"})
	public void verifySubmitButtonIsEnabled() {
		Assert.assertTrue(formy.isSubmitButtonEnabled());
	}
	
	
	
	
	
	
	
	
	
	@Test(dependsOnMethods = "verifyFirstNameIsDisplayed", dataProviderClass = FormyDataProvider.class,dataProvider = "firstNames")
	public void verifyFirstNameTakesInput(String firstName) {
		Assert.assertEquals(formy.enterAndGetFirstName(firstName),firstName);
	}
	
	@Test(dependsOnMethods = "verifyLastNameIsDisplayed",dataProviderClass = FormyDataProvider.class,dataProvider = "lastNames")
	public void verifyFirstName(String lastname) {
		Assert.assertEquals(formy.enterAndGetLastName(lastname),lastname);
	}
	
	@Test(dependsOnMethods = "verifyLastNameIsDisplayed",dataProviderClass = FormyDataProvider.class,dataProvider = "lastNames")
	public void verifyJobTitle(String jobtitle) {
		Assert.assertEquals(formy.enterAndGetJobTitle(jobtitle),jobtitle);
	}
	
	
	@Test
	public void verifyHighestEducation() {
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(formy.isHighSchoolSelected(),"HighSchool is not selected");
		softAssert.assertTrue(formy.isCollegeSelected(),"College is not selected");
		softAssert.assertTrue(formy.isGradSchoolSelected(),"GradSchool is not selected");
		softAssert.assertAll();
	}
	
	@Test
	public void verifyGender() {
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(formy.isMaleGenderSelected(),"Male was not selected");
		softAssert.assertTrue(formy.isFemaleGenderSelected(),"Female was not selected");
		softAssert.assertTrue(formy.isPreferNotToSaySelected(),"Prefer not to say was not selected");
		softAssert.assertAll();
	}
	
	@Test
	public void verifyYearsOfExperienceDropdown() {
		Assert.assertTrue(formy.isOption1Selected());
	}
	
	
	@Test(dataProviderClass = FormyDataProvider.class,dataProvider = "dates")
	public void verifyDateInput(String specDate) throws InterruptedException {
		Assert.assertEquals(formy.enterAndGetDate(specDate),specDate);
	}
	
	@Test
	public void verifySubmitButton() {
//		Assert.assertTrue(formy.clickOnSubmit());
		Assert.assertTrue(false);
	}
	
	@AfterMethod(alwaysRun = true)
	public void captureScreenshot(ITestResult result) throws IOException {
	    String screenshotDirectory = result.isSuccess() ? "./target/screenshots/passed/" : "./target/screenshots/failed/";
	    String screenshotName = result.getName();
	    File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	    if(!Files.exists(Paths.get(screenshotDirectory))){  
	       new File(screenshotDirectory).mkdirs();
	    }
	    FileUtils.copyFile(screenshotFile, new File(screenshotDirectory + screenshotName + ".png"));  // Save the screenshot
	    
	}
	
	@AfterTest(alwaysRun = true)
	public void tearDown() {
		driver.quit();
	}
	
}