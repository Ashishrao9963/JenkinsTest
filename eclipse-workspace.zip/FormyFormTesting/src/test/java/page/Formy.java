package page;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Formy {
	WebDriver driver;
	WebDriverWait wait;
	public Formy(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	
	public Formy launchFormyFormPage() {
		driver.get("https://formy-project.herokuapp.com/form");
		return this;
	}
	
	
	@FindBy(id = "logo")
	private WebElement logo;
	
	public boolean isLogoDisplayed() {
		return logo.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='first-name']") private WebElement firstName;
	
	public boolean isFirstNameDisplayed() {
		return firstName.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='last-name']") private WebElement lastName;
	
	public boolean isLastNameDisplayed() {
		return lastName.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='job-title']") private WebElement jobTitle;
	
	public boolean isJobTitleDisplayed() {
		return jobTitle.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='radio-button-1']") private WebElement highSchool;
	@FindBy(xpath = "//*[@id='radio-button-2']") private WebElement college;
	@FindBy(xpath = "//*[@id='radio-button-3']") private WebElement gradSchool;
	
	public boolean isRadioButton1Displayed() {
		return highSchool.isDisplayed();
	}
	public boolean isRadioButton2Displayed() {
		return college.isDisplayed();
	}
	public boolean isRadioButton3Displayed() {
		return gradSchool.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='checkbox-1']") private WebElement maleGender;
	@FindBy(xpath = "//*[@id='checkbox-2']") private WebElement femaleGender;
	@FindBy(xpath = "//*[@id='checkbox-3']") private WebElement preferNotToSay;
	public boolean isCheckbox1Displayed() {
		return maleGender.isDisplayed();
	}
	public boolean isCheckbox2Displayed() {
		return femaleGender.isDisplayed();
	}
	public boolean isCheckbox3Displayed() {
		return preferNotToSay.isDisplayed();
	}
	
	@FindBy(xpath = "//*[@id='select-menu']") private WebElement yearsOfExp;
	public boolean isYearsOfExperienceDisplayed() {
		return yearsOfExp.isDisplayed();
	}
	
	public boolean isFirstOptionDisplayed() {
		Select select = new Select(yearsOfExp);
		return select.getOptions().stream().anyMatch(e-> e.getText().equals("0-1"));
	}
	
	@FindBy(xpath = "//*[@id='datepicker']") private WebElement date;
	
	public boolean isDateDisplayed() {
		return date.isDisplayed();
	}
	
	@FindBy(xpath = "//div[8]/a") private WebElement submitButton;
	
	public boolean isSubmitButtonEnabled() {
		return submitButton.isEnabled();
	}
	
	
	
	
	
	
	
	
	public Formy enterFirstName(String firstname) {
		firstName.click();
		firstName.clear();
		firstName.sendKeys(firstname);
		return this;
	}
	
	public String enterAndGetFirstName(String firstname) {
		return enterFirstName(firstname).firstName.getAttribute("value");
	}
	
	public Formy enterLastName(String lastname) {
		lastName.click();
		lastName.clear();
		lastName.sendKeys(lastname);
		return this;
	}
	
	public String enterAndGetLastName(String lastname) {
		return enterLastName(lastname).lastName.getAttribute("value");
	}
	
	public Formy enterJobTitle(String jobtitle) {
		jobTitle.click();
		jobTitle.clear();
		jobTitle.sendKeys(jobtitle);
		return this;
	}
	
	public String enterAndGetJobTitle(String jobtitle) {
		return enterJobTitle(jobtitle).jobTitle.getAttribute("value");
	}
	
	public Formy selectHighSchool() {
		highSchool.click();
		return this;
	}
	public boolean isHighSchoolSelected() {
		return selectHighSchool().highSchool.isSelected();
	}
	
	public Formy selectCollege() {
		college.click();
		return this;
	}
	public boolean isCollegeSelected() {
		return selectCollege().college.isSelected();
	}
	
	public Formy selectGradSchool() {
		gradSchool.click();
		return this;
	}
	public boolean isGradSchoolSelected() {
		return selectGradSchool().gradSchool.isSelected();
	}
	
	public Formy selectMaleGender() {
		maleGender.click();
		return this;
	}
	public boolean isMaleGenderSelected() {
		return selectMaleGender().maleGender.isSelected();
	}
	
	public Formy selectFemaleGender() {
		femaleGender.click();
		return this;
	}
	public boolean isFemaleGenderSelected() {
		return selectFemaleGender().femaleGender.isSelected();
	}
	
	public Formy selectPreferNotToSay() {
		preferNotToSay.click();
		return this;
	}
	public boolean isPreferNotToSaySelected() {
		return selectPreferNotToSay().preferNotToSay.isSelected();
	}
	
	@FindBy(xpath = "//option[2]") private WebElement option; 
	
	
	public Formy selectOption1() {
		yearsOfExp.click();
		option.click();
		return this;
	}
	public boolean isOption1Selected() {
		return selectOption1().option.isDisplayed();
	}
	
	
	
	
	public Formy enterDate(String specDate) {
		date.clear();
		date.sendKeys(specDate);
		date.sendKeys(Keys.RETURN);
		return this;
	}
	public String enterAndGetDate(String specDate) throws InterruptedException {
		return enterDate(specDate).date.getAttribute("value");
	}
	
	@FindBy(xpath = "//h1") private WebElement formSubmitResponse;
	public boolean clickOnSubmit() {
		submitButton.click();
		return formSubmitResponse.isDisplayed();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}