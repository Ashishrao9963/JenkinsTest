package stepdefinitions;

import static io.restassured.RestAssured.baseURI;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;
import page.Homepage;

import java.util.ArrayList;
import java.util.List;

public class BooksStepDef {
    Response response;
    WebDriver driver;
    Homepage homepage;
    @Before
    public void settingUp(){
        driver=new ChromeDriver();
        driver.get("https://demoqa.com/books/");
        driver.manage().window().maximize();
        this.homepage=new Homepage(driver);
    }


    @Given("I make a GET call to the API")
    public void iMakeAGETCallToTheAPI() {
        baseURI = "https://demoqa.com/BookStore/v1/Books";
        response = RestAssured.given().request(Method.GET);
    }

    @Then("the books should be displayed")
    public void theBooksShouldBeDisplayed() {
        List<String> apiResponse = homepage.getBookAuthorsAndPublishers().stream().map(WebElement::getText).filter(y->!y.equals(" ")).toList();
        System.out.println(apiResponse);
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(apiResponse,getExpectedData());
    }

    private List<String> getExpectedData() {
        List<String> listOfTitles  = response.jsonPath().getList("books.findAll { it.title }.title");
        List<String> listOfAuthors  = response.jsonPath().getList("books.findAll { it.author }.author");
        List<String> listOfPublishers  = response.jsonPath().getList("books.findAll { it.publisher }.publisher");


        List<String> result = new ArrayList<>();
        for(int i = 0; i < listOfTitles.size(); i++) {
            result.add(listOfTitles.get(i));
            result.add(listOfAuthors.get(i));
            result.add(listOfPublishers.get(i));
        }
        System.out.println(result);
        return result;
    }
}
