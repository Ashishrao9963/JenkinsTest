package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DocumentationStepDefs {

    WebDriver driver;
    private static final String HOMEPAGE_URI = "https://dog.ceo/dog-api/";

    @Given("I am on the dog homepage")
    public void iAmOnTheDogHomepage() throws InterruptedException {
        driver = new ChromeDriver();
        driver.navigate().to(HOMEPAGE_URI);
    }

    @When("I click on documentation")
    public void iClickOnDocumentation() throws InterruptedException {
        WebElement documentationLink = driver.findElement(By.xpath("//li[1]/a"));
        documentationLink.click();
    }

    @Then("endpoints should be displayed")
    public void endpointsShouldBeDisplayed() {
        WebElement endpointsText = driver.findElement(By.xpath("//div[3]/h3[1]"));
        Assert.assertTrue(endpointsText.isDisplayed());
    }
}
