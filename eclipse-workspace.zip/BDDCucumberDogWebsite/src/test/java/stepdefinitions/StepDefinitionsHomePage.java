package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.sql.SQLOutput;

public class StepDefinitionsHomePage {

    WebDriver driver;
    String initJsonResponse;
    String finalJsonResponse;
    private static final String HOMEPAGE_URI = "https://dog.ceo/dog-api/";
    @Given("I am on the dog UI homepage")
    public void iAmOnTheDogUIHomepage() throws InterruptedException {
        driver = new ChromeDriver();
        driver.navigate().to(HOMEPAGE_URI);

    }

    @When("I click on Fetch")
    public void iClickOnFetch() {
        WebElement response = driver.findElement(By.xpath("//pre"));
        initJsonResponse = response.getText();
        WebElement fetchButton = driver.findElement(By.xpath("//a[@class='get-dog button']"));
        fetchButton.click();
    }

    @Then("The response body should change")
    public void theResponseBodyShouldChange() {
        WebElement response = driver.findElement(By.xpath("//pre"));
        finalJsonResponse = response.getText();
        Assert.assertEquals(initJsonResponse,finalJsonResponse);
    }
}
