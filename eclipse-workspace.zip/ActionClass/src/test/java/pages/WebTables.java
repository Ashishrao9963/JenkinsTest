package pages;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class WebTables {
	
	
	WebDriver driver;
	
	public Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
			.pollingEvery(Duration.ofSeconds(1))
			.withTimeout(Duration.ofSeconds(20))
			.ignoring(NoSuchElementException.class)
			.ignoring(NullPointerException.class);
	
	
	public WebTables(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}	
	
	@FindBy(xpath = "//*[@id='table1']/tbody/tr/td") public List<WebElement> tableValues;
	
	
	
	
	
	
	
	
	
	
	
	
	
}