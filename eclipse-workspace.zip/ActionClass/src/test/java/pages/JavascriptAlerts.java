package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JavascriptAlerts {
	
	WebDriver driver;
	
	public JavascriptAlerts(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//button[@onclick='jsAlert()']") WebElement jsAlert;
	
	@FindBy(xpath = "//button[@onclick='jsConfirm()']") WebElement jsConfirm;
	
	@FindBy(xpath = "//button[@onclick='jsPrompt()']") WebElement jsPrompt;
	
	public String switchAndReturnAlertText() {
		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		alert.accept();
		return alertText;
	}
	
	public String acceptJsAlert() {
		jsAlert.click();
		return switchAndReturnAlertText();
	}
	
	public String acceptJsConfirm() {
		driver.switchTo().defaultContent();
		jsConfirm.click();
		return switchAndReturnAlertText();
	}
	
	public String acceptJsPrompt() {
		driver.switchTo().defaultContent();
		jsPrompt.click();
		return switchAndReturnAlertText();
	}
	
}