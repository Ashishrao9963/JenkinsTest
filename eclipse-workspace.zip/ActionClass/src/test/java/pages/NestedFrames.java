package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NestedFrames {
	
	WebDriver driver;
	
	public NestedFrames(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(name = "frame-top") WebElement topFrame;
	
	@FindBy(name = "frame-left") WebElement leftFrame;
	@FindBy(xpath = "/html/body") WebElement body;
	
	@FindBy(name = "frame-middle") WebElement middleFrame;
	@FindBy(xpath = "//*[@id='content']") WebElement middleBody;
	
	@FindBy(name = "frame-right") WebElement rightFrame;
	
	@FindBy(name = "frame-bottom") WebElement bottomFrame;
	
	
	public String getLeftFrameText() {
		driver.switchTo().frame(topFrame);
		driver.switchTo().frame(leftFrame);
		return body.getText();
	}
	
	public String getMiddleFrameText() {
		driver.switchTo().parentFrame();
		driver.switchTo().frame(middleFrame);
		return middleBody.getText();
	}
	
	public String getRightFrameText() {
		driver.switchTo().parentFrame();
		driver.switchTo().frame(rightFrame);
		return body.getText();
	}
	
	public String getBottomFrameText() {
		driver.switchTo().defaultContent();
		driver.switchTo().frame(bottomFrame);
		return body.getText();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}