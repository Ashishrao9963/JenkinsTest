package test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.JavascriptAlerts;
import pages.NestedFrames;
import pages.WebTables;

public class DrawSquareTest {

	WebDriver driver;

	@BeforeMethod
	public void setUpDriver() {
		driver = new ChromeDriver();
	}

	// 1
	@Test
	public void verifyCheckBoxes() {
		driver.navigate().to("http://the-internet.herokuapp.com/checkboxes");
		driver.manage().window().maximize();
		WebElement checkBox1 = driver.findElement(By.xpath("//input[1]"));
		checkBox1.click();
		WebElement checkBox2 = driver.findElement(By.xpath("//input[2]"));
		checkBox2.click();

		SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(checkBox1.isSelected());
		softAssert.assertFalse(checkBox2.isSelected());
		softAssert.assertAll();
	}

	// 2
	@Test
	public void verifyUrl() {
		driver.navigate().to("http://the-internet.herokuapp.com/dynamic_content");
		driver.manage().window().maximize();
		WebElement makeContentStatic = driver.findElement(By.xpath("//p[2]/a"));
		makeContentStatic.click();
		assertThat(driver.getCurrentUrl(), containsString("?with_content=static"));
	}

	@Test
	public void verifyParaBody() {
		driver.navigate().to("http://the-internet.herokuapp.com/dynamic_content");
		driver.manage().window().maximize();
		WebElement para = driver.findElement(By.xpath("//*[@id='content']/div[3]/div[2]"));
		String beforeText = para.getText();
		WebElement makeContentStatic = driver.findElement(By.xpath("//p[2]/a"));
		makeContentStatic.click();
		WebElement paraAfter = driver.findElement(By.xpath("//*[@id='content']/div[3]/div[2]"));
		Assert.assertNotEquals(beforeText, paraAfter.getText());
	}

	// 3
	@Test
	public void verifyMultipleWindows() {
		driver.navigate().to("http://the-internet.herokuapp.com/windows");
		driver.manage().window().maximize();
		WebElement clickHere = driver.findElement(By.linkText("Click Here"));
		clickHere.click();
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> iterator = windowHandles.iterator();
		iterator.next();
		String windowHandle = iterator.next();
		driver.switchTo().window(windowHandle);
		Assert.assertEquals(driver.getTitle(), "New Window");

	}

	// 4
	@Test
	public void verifyFourFramesText() {
		driver.navigate().to("http://the-internet.herokuapp.com/nested_frames");
		NestedFrames frames = new NestedFrames(driver);
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(frames.getLeftFrameText(), "LEFT", "Left Test has failed");
		softAssert.assertEquals(frames.getMiddleFrameText(), "MIDDLE", "Middle Test has failed");
		softAssert.assertEquals(frames.getRightFrameText(), "RIGHT", "Right Test has failed");
		softAssert.assertEquals(frames.getBottomFrameText(), "BOTTOM", "Bottom Test has failed");
		softAssert.assertAll();
	}

	// 5
	@Test
	public void verifyAlerts() throws InterruptedException {
		driver.navigate().to("http://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();

		JavascriptAlerts alerts = new JavascriptAlerts(driver);
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(alerts.acceptJsAlert(), "I am a JS Alert");
		softAssert.assertEquals(alerts.acceptJsConfirm(), "I am a JS Confirm");
		softAssert.assertEquals(alerts.acceptJsPrompt(), "I am a JS prompt");
		softAssert.assertAll();
	}

	// 6
	@Test
	public void verifyDropdown() {
		driver.navigate().to("http://the-internet.herokuapp.com/dropdown");
		driver.manage().window().maximize();
		WebElement dropdown = driver.findElement(By.id("dropdown"));
		Select select = new Select(dropdown);
		select.selectByValue("1");
		WebElement selectedOption = driver.findElement(By.xpath("//option[@selected='selected']"));
		select.selectByValue("2");
		WebElement selectedOption2 = driver.findElement(By.xpath("//option[@selected='selected']"));
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(selectedOption.getAttribute("value"), "1");
		softAssert.assertEquals(selectedOption2.getAttribute("value"), "2");
		softAssert.assertAll();

	}

	// 7
	@Test
	public void verifyTableData() {
		driver.navigate().to("http://the-internet.herokuapp.com/tables");
		WebTables table = new WebTables(driver);
		table.wait.until(ExpectedConditions.visibilityOfAllElements(table.tableValues));
		List<String> actualTableValues = table.tableValues.stream().map(x -> x.getText()).toList();
		List<String> expectedTableValues = List.of("Smith", "John", "jsmith@gmail.com", "$50.00",
				"http://www.jsmith.com", "edit delete", "Bach", "Frank", "fbach@yahoo.com", "$51.00",
				"http://www.frank.com", "edit delete", "Doe", "Jason", "jdoe@hotmail.com", "$100.00",
				"http://www.jdoe.com", "edit delete", "Conway", "Tim", "tconway@earthlink.net", "$50.00",
				"http://www.timconway.com", "edit delete");
		assertEquals(actualTableValues, expectedTableValues);
	}

	// 8
	@Test
	public void verifyStringInputs() {
		driver.navigate().to("http://the-internet.herokuapp.com/inputs");
		driver.manage().window().maximize();
		WebElement input = driver.findElement(By.xpath("//input"));
		input.sendKeys("Shivanath");
		Assert.assertEquals(input.getText(), "");
	}

	// 9
	@Test
	public void verifyIFrameText() {
		driver.navigate().to("http://the-internet.herokuapp.com/tinymce");
		driver.manage().window().maximize();
		WebElement edit = driver.findElement(By.xpath("//*/div[1]/div[1]/div[1]/button[2]/span"));
		assertThat(edit.getText(), equalTo("Edit"));
	}

	@Test
	public void verifyIFrameTextEntering() throws InterruptedException {
		driver.navigate().to("http://the-internet.herokuapp.com/tinymce");
		driver.switchTo().frame("mce_0_ifr");
		WebElement textBox = driver.findElement(By.xpath("//p"));
		textBox.clear();
		textBox.sendKeys("Shivanath");
		WebElement actualText = driver.findElement(By.xpath("//p"));
		assertThat(actualText.getText(), equalTo("Shivanath"));
	}

	// 10
	@Test
	public void verifyDrawingSquare() {
		driver.navigate().to("https://www.youidraw.com/apps/painter/");
		driver.manage().window().maximize();
		WebElement canvas = driver.findElement(By.xpath("//*[@id='catch']"));
		new Actions(driver).clickAndHold(canvas).moveByOffset(100, 0).moveByOffset(0, 100).moveByOffset(-100, 0)
				.moveByOffset(0, -100).release().perform();
	}

	@AfterMethod
	public void teardownDriver() {
		driver.quit();
	}

}