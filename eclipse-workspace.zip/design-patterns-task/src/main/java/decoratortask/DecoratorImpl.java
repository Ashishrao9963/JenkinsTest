package decoratortask;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DecoratorImpl {
	
	private static final Logger LOGGER = LogManager.getLogger(DecoratorImpl.class);

	public static void main(String[] args) {
		MobileVersion mobileVersion = new MobileVersion();
		WidgetDecorator widgetDecorator1 = new WidgetDecorator(mobileVersion);
		LOGGER.info(widgetDecorator1.getRank());
		
		
		DesktopVersion desktopVersion = new DesktopVersion();
		WidgetDecorator widgetDecorator2 = new WidgetDecorator(desktopVersion);
		LOGGER.info(widgetDecorator2.getRank());
		
		
	}
}