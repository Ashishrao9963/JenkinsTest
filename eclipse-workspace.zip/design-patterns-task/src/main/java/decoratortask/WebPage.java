package decoratortask;

public interface WebPage {
	
	Integer getRank();
	
}