package decoratortask;

public class DesktopVersion implements WebPage {
	
	private static final Integer DESKTOP_VERSION_RANK = 25;
		
	@Override
	public Integer getRank() {
		return DESKTOP_VERSION_RANK;
	}

}
