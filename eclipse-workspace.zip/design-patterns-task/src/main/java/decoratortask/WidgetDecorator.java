package decoratortask;

public class WidgetDecorator extends MobileVersion{
	
	private static final Integer WIDGET_RANK = 3;
	private final WebPage webPage;
	
	public WidgetDecorator(WebPage webPage) {
		super();
		this.webPage = webPage;
	}
	
	@Override
	public Integer getRank() {
		return webPage.getRank()+WIDGET_RANK;
	}
	
}