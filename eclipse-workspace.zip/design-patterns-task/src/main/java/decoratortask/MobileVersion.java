package decoratortask;

public class MobileVersion implements WebPage {
	
	private static final Integer MOBILE_VERSION_RANK = 10;
	
	@Override
	public Integer getRank() {
		return MOBILE_VERSION_RANK;
	}
}
