package builderpattern;

public class BicycleImpl {
	
	public static void main(String[] args) {
		
		Bicycle bicycle = Bicycle.builder()
							.hasGears(true)
							.hasDoubleStands(true)
							.hasDoubleSeats(false)
							.hasCarrier(true).build();
		
		System.out.println(bicycle);
	}
	
}