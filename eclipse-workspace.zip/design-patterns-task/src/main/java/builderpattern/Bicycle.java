package builderpattern;

public class Bicycle {
	
	Boolean hasGears;
	Boolean hasDoubleStands;
	Boolean hasDoubleSeats;
	Boolean hasCarrier;
	
	public static BicycleBuilder builder() {
		return new BicycleBuilder();
	}
	
	public static class BicycleBuilder{
		private Boolean hasGears;
		private Boolean hasDoubleStands;
		private Boolean hasDoubleSeats;
		private Boolean hasCarrier;
		
		public BicycleBuilder hasGears(final Boolean hasGears) {
			this.hasGears = hasGears;
			return this;
		}
		
		public BicycleBuilder hasDoubleStands(final Boolean hasDoubleStands) {
			this.hasDoubleStands = hasDoubleStands;
			return this;
		}
		
		public BicycleBuilder hasDoubleSeats(final Boolean hasDoubleSeats) {
			this.hasDoubleSeats = hasDoubleSeats;
			return this;
		}
		
		public BicycleBuilder hasCarrier(final Boolean hasCarrier) {
			this.hasCarrier = hasCarrier;
			return this;
		}
		
		public Bicycle build() {
			Bicycle bicycle = new Bicycle();
			bicycle.hasGears = hasGears;
			bicycle.hasDoubleStands = hasDoubleStands;
			bicycle.hasDoubleSeats = hasDoubleSeats;
			bicycle.hasCarrier = hasCarrier;
			return bicycle;
		}
		
	}

	@Override
	public String toString() {
		return "Bicycle hasGears : " + hasGears + ", hasDoubleStands : " + hasDoubleStands 
				+ ", hasDoubleSeats : "	+ hasDoubleSeats + ", hasCarrier : " + hasCarrier ;
	}
	
	

}	
//	Home Task 1
//	While manufacturing a Bicycle, I provide flexibility to my customer to choose
//	if they want gears, double stands, double seats, carrier etc. A customer can opt-in or 
//	opt-out for any of the choices I provide. However once the choice is made the choice 
//	can not be changed.
//
//	Write code to represent this model and build a bicycle , leaving the flexibility
//	of selection of extra fittings to the customer. 
//	------------------------------------------------------------
//	Acceptance criteria:
//	1. Solve the problem using pattern
//	2. Optimize the code
//	3. No Sonar Violations