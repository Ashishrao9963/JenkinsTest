package strategypattern;

interface PhoneCameraApp {
	
	public void takePhoto();

	public void editPhoto();

	public void savePhoto();
	
}