package strategypattern;

public class ShareByText implements SharePhoto{

	@Override
	public void sharePhoto(Photo photo) {
		//some code here
		System.out.println("Photo sent by Text!");
	}
}