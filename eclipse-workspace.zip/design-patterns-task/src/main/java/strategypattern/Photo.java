package strategypattern;

public class Photo {
	
	
	
}