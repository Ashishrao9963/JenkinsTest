package strategypattern;

public class CameraAppImpl {
	
		private final SharePhoto strategy;

	    public CameraAppImpl(SharePhoto strategy){
	        this.strategy = strategy;
	    }
	    
	    Photo photo = new Photo();
	    
	    public void sharePhoto(){
	        this.strategy.sharePhoto(photo);
	    }

}