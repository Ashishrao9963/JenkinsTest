package strategypattern;

public class BasicCameraApp implements PhoneCameraApp{

	@Override
	public void takePhoto() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editPhoto() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void savePhoto() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}