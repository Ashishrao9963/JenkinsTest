package strategypattern;

public class ShareByEmail implements SharePhoto{

	@Override
	public void sharePhoto(Photo photo) {
		//some code here
		System.out.println("Photo sent by Email!");
	}
	
	
	
}