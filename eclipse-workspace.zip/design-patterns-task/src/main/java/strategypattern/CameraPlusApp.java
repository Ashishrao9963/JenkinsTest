package strategypattern;

public class CameraPlusApp implements PhoneCameraApp{

	@Override
	public void takePhoto() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editPhoto() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void savePhoto() {
		// TODO Auto-generated method stub
		
	}
}