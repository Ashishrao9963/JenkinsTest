package strategypattern;

public interface SharePhoto {
	public void sharePhoto(Photo photo);
}