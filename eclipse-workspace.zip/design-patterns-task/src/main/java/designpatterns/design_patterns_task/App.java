package designpatterns.design_patterns_task;

import java.util.logging.Logger;

public class App {
	public static void main(String[] args) {
		final Logger LOGGER = Logger.getLogger(App.class.getName());
		
		LOGGER.info("Hello World!");
		CandyMaker candyMaker1 = CandyMaker.getInstance();
		CandyMaker candyMaker2 = CandyMaker.getInstance();
		System.out.println(candyMaker1+" "+candyMaker2);
//		LOGGER.info(candyMaker1+" "+candyMaker2);
	}
}
