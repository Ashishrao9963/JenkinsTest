package lambdaPackage;

import java.util.*;

public class DescOrderTreeMap {

	public static void main(String[] args) {
//		Create a TreeMap that sorts the given set of values in descending order
		TreeMap<Integer, Integer> treeMap = new TreeMap<>();
		
		treeMap.put(235, 24);
		treeMap.put(452, 35);
		treeMap.put(342, 674);
		treeMap.put(5, 345);
		treeMap.put(32, 45);
		treeMap.put(55, 778);
		treeMap.put(67, 89);
		treeMap.put(123, 56);
		
		TreeMap<Integer, Integer> revOrder = new TreeMap<>((x, y)->treeMap.get(y).compareTo(treeMap.get(x)));
		revOrder.putAll(treeMap);
		System.out.println(revOrder);
	}

}