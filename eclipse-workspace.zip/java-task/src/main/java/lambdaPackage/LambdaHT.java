package lambdaPackage;

import java.util.function.Predicate;

public class LambdaHT {

	public static void main(String[] args) {
//		Write the below programs with and without help of Lambda expressions
//		1. Check if a given string is a palindrome
		Predicate<String> x = (str)-> {
			String reversed = new StringBuilder(str).reverse().toString();
			return str.equalsIgnoreCase(reversed);
		};
		System.out.println(x.test("lever"));
		
		
		System.out.println(isPalindrome("level"));
	}
	
	public static boolean isPalindrome(String str) {
		String reversed = new StringBuilder(str).reverse().toString();
		return str.equalsIgnoreCase(reversed);
	}	
}