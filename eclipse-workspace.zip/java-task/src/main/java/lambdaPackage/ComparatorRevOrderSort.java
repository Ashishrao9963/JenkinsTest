package lambdaPackage;

import java.util.*;

public class ComparatorRevOrderSort {

	public static void main(String[] args) {
//		Use Comparator interface to sort given list of numbers in reverse order
		List<Integer> listOfNumbers = new ArrayList<>();
		listOfNumbers.add(235);
		listOfNumbers.add(452);
		listOfNumbers.add(342);
		listOfNumbers.add(5);
		listOfNumbers.add(32);
		listOfNumbers.add(55);
		listOfNumbers.add(67);
		listOfNumbers.add(123);
		
		listOfNumbers.sort((left,right) -> right.compareTo(left));
		System.out.println(listOfNumbers);
		
		
		
		System.out.println(reverseOrder(listOfNumbers));
	}
	
	
	public static List<Integer> reverseOrder(List<Integer> list){
		Collections.sort(list, Comparator.reverseOrder());
		return list;
	}
}