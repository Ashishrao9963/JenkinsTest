package lambdaPackage;

import java.util.HashMap;
import java.util.function.*;

public class StringRotations {

	public static void main(String[] args) {
//		write a program to check if two strings are rotations of each other.
		
		BiPredicate<String, String> object1 = (x,y) -> {
			boolean flag;
			if(x.length() != y.length()) {
				flag = false;
			}
			else {
				String tempo = x+x;
				flag = tempo.contains(y);
			}
			
			return flag;
		};
		System.out.println(object1.test("erbottlewat", "waterbottle"));
		
		
		
		System.out.print(stringRotation("waterbottle", "erbottlewat"));
		
		
	}
	
	public static boolean stringRotation(String str, String str2) {
		boolean flag;
		if(str.length()!=str2.length()) {
			flag = false;
		}
		else {
			String temp = str + str ;
			flag = temp.contains(str2);
		}
		return flag;
		
		
	}
	
	
	
	
	
}