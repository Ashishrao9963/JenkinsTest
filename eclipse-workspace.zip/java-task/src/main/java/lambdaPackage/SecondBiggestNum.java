package lambdaPackage;

import java.util.*;
import java.util.function.Function;

public class SecondBiggestNum {

	public static void main(String[] args) {
//		2. Find the 2nd biggest number in the given list of numbers
		List<Integer> listOfNumbers = new ArrayList<>();
		listOfNumbers.add(235);
		listOfNumbers.add(452);
		listOfNumbers.add(342);
		listOfNumbers.add(5);
		listOfNumbers.add(32);
		listOfNumbers.add(55);
		listOfNumbers.add(67);
		
		Function<List<Integer>, Integer> lambdaObj = (p)->{
			Collections.sort(p);
			Collections.reverse(p);
			int flag;
			if(p.size()==0)
				flag =0;
			else if(p.size()==1)
				flag = p.get(0);
			else {
				flag = p.get(1);
			}
			return flag;
		};
		System.out.println(lambdaObj.apply(listOfNumbers));
		
		
		
		System.out.println(secondBiggest(listOfNumbers));
	}
	
	
	public static int secondBiggest(List<Integer> list) {
		int flag ;
		if(list.size()==0) {
			flag = 0;
		}
		else if(list.size()==1) {
			flag = list.get(0);
		}
		else { 
			Collections.sort(list);
			Collections.reverse(list);
			flag = list.get(1);
		}
		return flag;
	}

}
