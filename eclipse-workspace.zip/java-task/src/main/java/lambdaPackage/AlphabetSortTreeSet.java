package lambdaPackage;

import java.util.TreeSet;

public class AlphabetSortTreeSet {

	public static void main(String[] args) {
//		Create a TreeSet that sorts the given set of Employees in
//		the alphabetic order of their name
		TreeSet<String> ts = new TreeSet<>((x,y) -> x.compareTo(y));
		ts.add("Micha");
		ts.add("Sally");
		ts.add("Molly");
		ts.add("bertha");
		ts.add("Harry");
		ts.add("ron");
		ts.add("Hermoine");
		ts.add("taylor");
		
		
		
		System.out.println(ts);
		
		
		
		
	}

}
