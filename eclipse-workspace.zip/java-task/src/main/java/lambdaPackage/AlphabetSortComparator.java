package lambdaPackage;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AlphabetSortComparator {

	public static void main(String[] args) {
//		Use Comparator interface to sort given list of Employees 
//		in the alphabetic order of their name
		List<String> listOfNumbers = new ArrayList<>();
		listOfNumbers.add("Micha");
		listOfNumbers.add("Sally");
		listOfNumbers.add("Molly");
		listOfNumbers.add("bertha");
		listOfNumbers.add("Harry");
		listOfNumbers.add("ron");
		listOfNumbers.add("Hermoine");
		listOfNumbers.add("taylor");
		
		listOfNumbers.sort((left,right) -> left.compareTo(right));
		System.out.println(listOfNumbers);
		
		
		bruteForce(listOfNumbers);
		
	}
	public static void bruteForce(List<String> list){
		list.sort(Comparator.naturalOrder());
		System.out.println(list);
	}
	
	
	
	
	
	
	
}