package lambdaPackage;

public class ThreadsTask {

	public static void main(String[] args) {
		
		Runnable printNumbers=()->
		{
			for(int i=1 ; i<=20 ; i++)
			{
				System.out.println(i);
			}
		};
		Thread t=new Thread(printNumbers);
		t.start();
	}

}