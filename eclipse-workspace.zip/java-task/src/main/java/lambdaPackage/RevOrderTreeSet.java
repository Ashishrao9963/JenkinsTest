package lambdaPackage;

import java.util.*;

public class RevOrderTreeSet {

	public static void main(String[] args) {
//		Create a TreeSet that sorts the given set of numbers in reverse order
		TreeSet<Integer> ts = new TreeSet<>((x,y) -> y.compareTo(x));
		ts.add(235);
		ts.add(452);
		ts.add(342);
		ts.add(5);
		ts.add(32);
		ts.add(55);
		ts.add(67);
		ts.add(123);
		
		System.out.println(ts);
	}
}