package lambdaPackage;

import java.util.*;

public class AlphabetSortTreeMap {

	public static void main(String[] args) {
//		Create a TreeMap that sorts the given set of employees in
//		descending order of their name
		TreeMap<String, String> treeMapSort = new TreeMap<>((x,y) -> y.compareTo(x));
		treeMapSort.put("Srikar", "Employee");
		treeMapSort.put("Shiva", "HR");
		treeMapSort.put("Ikaris", "Subaru");
		treeMapSort.put("Gemma", "Outing");
		treeMapSort.put("Spark", "Employee");
		treeMapSort.put("Aurora", "Yahoo");
		treeMapSort.put("Krish", "Comedy");
		treeMapSort.put("Monty", "Employee");
		
		System.out.println(treeMapSort);
		
		
		
		
		
	}

}
