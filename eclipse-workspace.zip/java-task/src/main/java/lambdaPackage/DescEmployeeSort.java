package lambdaPackage;

import java.util.*;

public class DescEmployeeSort {

	public static void main(String[] args) {
//		Use Collections.Sort to sort the given list of Employees in
//		descending order of their name
		List<String> listOfEmployees = new ArrayList<String>();
		listOfEmployees.add("Hikari");
		listOfEmployees.add("Neo");
		listOfEmployees.add("Eric");
		listOfEmployees.add("Sam");
		listOfEmployees.add("Lancali");
		listOfEmployees.add("Sony");
		listOfEmployees.add("Ryle");
		listOfEmployees.add("Lily");
		listOfEmployees.add("Atlas");
		
		Collections.sort(listOfEmployees, (x,y) -> y.compareTo(x));
		
		System.out.println(listOfEmployees);
		
	}

}
