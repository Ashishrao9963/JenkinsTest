package biFunction;

import java.util.*;
import java.util.function.BiFunction;

import com.java8.app.java_task.Product;

public class BiFuncImplementation {

	public static void main(String[] args) {
		
		Product product1 = new Product("Shyam", 13000, "Electronics", "B");
		Product product2 = new Product("Shiva", 1000, "IT", "A");
		Product product3 = new Product("Trish", 800, "Mgmt", "A");
		Product product4 = new Product("Krish", 90, "IT", "B");
		Product product5 = new Product("Louis", 10, "Electronics", "C");
		Product product6 = new Product("Soups", 20, "Electronics", "D");
		Product product7 = new Product("Aruna", 1100, "Mgmt", "D");
		Product product8 = new Product("Mani", 3500, "Mgmt", "D");
		Product product9 = new Product("Raghav", 8700, "Mgmt", "D");
		
		List<Product> productsList = new ArrayList<>();
		productsList.add(product1);
		productsList.add(product2);
		productsList.add(product3);
		productsList.add(product4);
		productsList.add(product5);
		productsList.add(product6);
		productsList.add(product7);
		productsList.add(product8);
		productsList.add(product9);
//		1. Given the name and price of the product, write a BiFunction
//		to create a product. 
		createProduct("Shivanath",Double.valueOf(2300));
		
		HashMap<Product, Integer> cart = new HashMap<>();
		
		cart.put(product1, 21);
		cart.put(product2, 5);
		cart.put(product3, 31);
		cart.put(product4, 2);
		cart.put(product5, 1);
		cart.put(product6, 26);
		cart.put(product7, 16);
		cart.put(product8, 7);
		cart.put(product9, 4);
		
		costOfCart(cart);
		
	}
	
	public static void createProduct(String name, Double price) {
		BiFunction<String, Double, Product> t = (x, y) -> {return new Product(x, y, "electronics", "good");};
		Product prod1 = t.apply(name, price);
		System.out.println(prod1);
	}
	
	public static void costOfCart(Map<Product,Integer> cartAsMap) {
		BiFunction<Product, Integer, Double> totalCost=(x,y)->(y*x.getPrice());
		double cartCost=0;
		for(Map.Entry<Product,Integer> entry : cartAsMap.entrySet())
		{
			cartCost += totalCost.apply(entry.getKey(),entry.getValue());
		}
		System.out.println("Cart cost: "+cartCost);
	}
	
	//Given the Product and quantity of the products, write a Bi-Function to 
	//calculate the cost of products. A cart is a map of product and quantity. 
	//Given the cart, calculate the cost of the cart.
	
}