package BinaryUnary;

import java.util.Random;
import java.util.function.Supplier;

public class SupplierIntImple {

	public static void main(String[] args) {
//		Write a IntSupplier to give random int below 5000.
		Supplier<Integer> randInt = () -> new Random().nextInt(5000);
		System.out.println(randInt.get());
		
		
	}

}
