package BinaryUnary;

import java.util.function.*;

public class IntegerImple {

	public static void main(String[] args) {
//		Pre-Conditions
//		- Define a Product class with name, price, category, grade
//
//		1. Write an IntPredicate to verify if the given number is a prime number
//		2. Write an IntConsumer to print square of the given number
//		3. Write a IntSupplier to give random int below 5000. 
		
		int n = 2;
		
		IntPredicate primeOrNot = x -> {
			boolean flag;
			if(x<=1)
				flag = false;
			for(int i=2; i<=Math.sqrt(x); i++) {
				if(x%i==0){
					flag = false;
				}
			}
			flag = true;
			return flag;
		};
		System.out.println(n + " is prime or not: " + primeOrNot.test(n));
	}
}