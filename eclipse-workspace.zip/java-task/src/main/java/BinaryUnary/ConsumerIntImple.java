package BinaryUnary;

import java.util.function.IntConsumer;

public class ConsumerIntImple {

	public static void main(String[] args) {
//		Write an IntConsumer to print square of the given number
		
		IntConsumer square = x -> System.out.println(x*x);
		square.accept(7);
		
		
		
	}

}
