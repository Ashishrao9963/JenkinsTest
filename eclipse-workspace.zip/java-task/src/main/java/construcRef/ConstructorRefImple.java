package construcRef;

interface EmployeeDetails
{
	Employee getEmployee(String name, String account, double salary);
}
 
public class ConstructorRefImple {

	public static void main(String[] args) {
		EmployeeDetails employeeDetails = Employee::new;
		Employee employee = employeeDetails.getEmployee("Shivanath","Savings", 23000);
		System.out.println(employee.toString());
	}
}
