package com.java8.app.java_task;

import java.util.*;
import java.util.function.*;

public class PredefinedFuncIntTask2 {
	/*1. Given a product write a consumer to print the product to appropriate
	medium depending on the print parameter. If the print parameter is set
	to file, consumer shall log the product to file, if not print on the console. 

	2. Write a Consumer to update the grade of the product as 'Premium' 
	if the price is > 1000/-. Given the product list, update the grade for each product
	and print all of the products. 

	3. Write a Consumer to update the name of the product to be suffixed with '*'
	if the price of product is > 3000/-. Given the product list, update the name
	for each product and print all of the products. 

	4. Print all the Premium grade products with name suffixed with '*'.
*/
	
	public static void main(String[] args) {
		
		List<Product> productsList = new ArrayList<>();
		productsList.add(new Product("Shyam", 13000, "Electronics", "B"));
		productsList.add(new Product("Shiva", 1000, "IT", "A"));
		productsList.add(new Product("Trish", 800, "Mgmt", "A"));
		productsList.add(new Product("Krish", 90, "IT", "B"));
		productsList.add(new Product("Louis", 10, "Electronics", "C"));
		productsList.add(new Product("Soups", 20, "Electronics", "D"));
		productsList.add(new Product("Aruna", 1100, "Mgmt", "D"));
		productsList.add(new Product("Mani", 3500, "Mgmt", "D"));
		productsList.add(new Product("Raghav", 8700, "Mgmt", "D"));
		
		
		System.out.println("Enter a number:");
		System.out.println("1 : Update the grade of the product as 'Premium'"
				+ " if the price is > 1000");
		System.out.println("2 : Update the name of the product to be suffixed"
				+ " with '*' if the price of product is > 3000");
		System.out.println("3 : Print all the Premium grade products with name"
				+ " suffixed with '*'");
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.close();
		switch(n) {
		case 1:
			for(Product pop: productsList) {
				System.out.println(premium(pop));
				System.out.println();
			}
			break;
		case 2:
			for(Product pop: productsList) {
				System.out.println(asterick(pop));
				System.out.println();
			}
			break;
		case 3:
			for(Product pop: productsList) {
				premiumAsterick(pop);
			}
			break;
		default:
			System.out.println("Invalid number");
			break;
		}
		
		System.out.println("--------------------This is Supplier--------------------");
		System.out.println("Random Product generated: ");
		ranProduct(productsList);
		
		System.out.println();
		System.out.println("Random OTP");
		randomOTP();	
	}
	
	//2. Write a Consumer to update the grade of the product as 'Premium' if the
	//price is > 1000/-. Given the product list, update the grade for each product
	//and print all of the products. 
	public static Product premium(Product x){
		Consumer<Product> premIum = i -> {
			if(i.getPrice()>1000) {
				i.setGrade("Premium");
			}
		};
		premIum.accept(x);
		return x;
	}
	
	
//	3. Write a Consumer to update the name of the product to be suffixed with '*'
//	if the price of product is > 3000/-. Given the product list, update the name
//	for each product and print all of the products. 
	public static Product asterick(Product x) {
		Consumer<Product> threeThousand = i -> {
			if(i.getPrice()>3000) {
				i.setName(i.getName().concat("*"));
			}
		};
		threeThousand.accept(x);
		return x;
	}
	
	
	//4. Print all the Premium grade products with name suffixed with '*'.
	public static void premiumAsterick(Product x) {
		premium(x);
		asterick(x);
		if(x.getName().endsWith("*")  &&  x.getGrade().equalsIgnoreCase("premium")) {
			System.out.println(x);
			System.out.println();
		}
	}
	
	
	//Supplier
	//Write a supplier to produce a random product. 
	public static void ranProduct(List<Product> prodList) {
		Supplier<Product> randomprod = () -> prodList.get((int)(Math.random()  * prodList.size()));
		System.out.println(randomprod.get());
	}
	
	//Write a supplier to produce a random OTP. 
	public static void randomOTP() {
		Supplier<Double> randomotp = () -> {
			return new Random().nextDouble(100000, 999999);
		};
		System.out.println((randomotp.get()).intValue());
	}
}