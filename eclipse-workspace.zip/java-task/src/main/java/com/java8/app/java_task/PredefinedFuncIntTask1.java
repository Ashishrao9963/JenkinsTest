package com.java8.app.java_task;

import java.util.*;
import java.util.function.*;

public class PredefinedFuncIntTask1 {

	public static void main(String[] args) {
		
		List<Product> productsList = new ArrayList<>();
		productsList.add(new Product("Shyam", 13000, "Electronics", "B"));
		productsList.add(new Product("Shiva", 1000, "IT", "A"));
		productsList.add(new Product("Trish", 800, "Mgmt", "A"));
		productsList.add(new Product("Krish", 90, "IT", "B"));
		productsList.add(new Product("Louis", 10, "Electronics", "C"));
		productsList.add(new Product("Soups", 20, "Electronics", "D"));
		productsList.add(new Product("Aruna", 1100, "Mgmt", "D"));
		productsList.add(new Product("Mani", 3500, "Mgmt", "D"));
		productsList.add(new Product("Raghav", 8700, "Mgmt", "D"));
		
		
		System.out.println("Enter a number:");
		System.out.println("1 : price of given product is greater than 1000");
		System.out.println("2 : check if the product is of electronics category");
		System.out.println("3 : product price is greater than 100/- which are"
							+ " in electronics category");
		System.out.println("4 : product price is greater than 100/- or product"
							+ " is in electronics category");
		System.out.println("5 : product price is less than 100/- and product"
							+ " is in electronics category.");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.close();
		switch(n) {
		case 1:
			for(Product pop: productsList) {
				greaterThanThou(pop);
			}
			break;
		case 2:
			for(Product pop: productsList) {
				printElectronics(pop);
			}
			break;
		case 3:
			for(Product pop: productsList) {
				electronicsGreaterThanHundred(pop);
			}
			break;
		case 4:
			for(Product pop: productsList) {
				greatThanHundOrElectronics(pop);
			}
			break;
		case 5:
			for(Product pop: productsList) {
				lessThanHundElectronics(pop);
			}
			break;
		default:
			System.out.println("Invalid number");
			break;
		}	
	}
	
	
	
	
	public static void greaterThanThou(Product x) {
		Predicate<Double> greaterThanThousand = i -> (i >1000);
		if(greaterThanThousand.test(x.getPrice())) {
			System.out.println(x);
			System.out.println();
		}
	}
	
	
	
	
	public static void printElectronics(Product x) {
		Predicate<Product> isElectronics = i -> "Electronics".equalsIgnoreCase(x.getCategory());
		if(isElectronics.test(x)) {
			System.out.println(x);
			System.out.println();
		}	
	}
	
	
	
	
	public static void electronicsGreaterThanHundred(Product x) {
		Predicate<Product> elecGreaterHun = i -> i.getPrice() >100;
		Predicate<Product> isElectronics = i -> "Electronics".equalsIgnoreCase(x.getCategory());
		if(elecGreaterHun.test(x) && isElectronics.test(x)) {
			System.out.println(x);
			System.out.println();
		}
	}
	
	
	
	
	public static void greatThanHundOrElectronics(Product x) {
		Predicate<Product> greatThanHun = i -> i.getPrice()>100;
		Predicate<Product> isElectronics = i -> "Electronics".equalsIgnoreCase(x.getCategory());
		if(greatThanHun.test(x) || isElectronics.test(x)) {
			System.out.println(x);
			System.out.println();
		}
	}
	
	
	
	
	public static void lessThanHundElectronics(Product x) {
		Predicate<Product> lessThanHund = i -> (i.getPrice()<100) && ("Electronics".equalsIgnoreCase(i.getCategory()));
		if(lessThanHund.test(x)) {
			System.out.println(x);
			System.out.println();
		}	
	}
}
