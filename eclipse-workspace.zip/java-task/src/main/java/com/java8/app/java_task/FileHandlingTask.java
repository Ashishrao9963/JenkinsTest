package com.java8.app.java_task;

import java.io.FileWriter;
import java.util.function.Consumer;
public class FileHandlingTask {
	
	public static void main(String[] args){
		printProduct(new Product("Geyser",2300,"Electronics","A"),"file");
	}
	
	public static void printProduct(Product product,String printParameter){
		Consumer<String> print=(medium)->{
			try{
				if("File".equalsIgnoreCase(medium)) {
					FileWriter newfile=new FileWriter("src/file.txt",true);
					newfile.write("Name: " + product.getName()+", Price: "+product.getPrice() + ", Category: "+product.getCategory() + ", Grade:"+product.getGrade());
					newfile.close();
					System.out.println("Written in file!");
				}
				else if("Console".equalsIgnoreCase(medium)){
					System.out.println(product);
				}
			}
			catch(Exception e){
					System.out.println(e.toString());
					e.printStackTrace();
				}
		};
		print.accept(printParameter);
	}
}