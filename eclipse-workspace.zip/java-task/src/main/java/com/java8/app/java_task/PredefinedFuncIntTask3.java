package com.java8.app.java_task;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class PredefinedFuncIntTask3 {

	public static void main(String[] args) {
		
		List<Product> productsList = new ArrayList<>();
		productsList.add(new Product("Shyam", 13000, "Electronics", "B"));
		productsList.add(new Product("Shiva", 1000, "IT", "A"));
		productsList.add(new Product("Trish", 800, "Mgmt", "A"));
		productsList.add(new Product("Krish", 90, "IT", "B"));
		productsList.add(new Product("Louis", 10, "Electronics", "C"));
		productsList.add(new Product("Soups", 20, "Electronics", "D"));
		productsList.add(new Product("Aruna", 1100, "Mgmt", "D"));
		productsList.add(new Product("Mani", 3500, "Mgmt", "D"));
		productsList.add(new Product("Raghav", 8700, "Mgmt", "D"));
		
		System.out.println("1. Calculate the cost of all products in a given list of products.");
		completeCost(productsList);
		
		System.out.println("2. Calculate the cost of all products whose prices is > 1000/- in the given list of products");
		costAbove1000(productsList);
		
		System.out.println("3. Calculate the cost of all electronic products in the given list of products.");
		electronicCost(productsList);
		
		System.out.println("4. Get all the products whose price is is > 1000/- and belongs to electronic category.");
		electronicGreaterThan1000(productsList);
	}
	
	public static void completeCost(List<Product> listOfProd) {
		Function<List<Product>,Double> costOfProducts = (x)->x.stream().mapToDouble(y->y.getPrice()).sum();
		System.out.println(costOfProducts.apply(listOfProd));
	}
	
	public static void costAbove1000(List<Product> listOfProd) {
		Function<List<Product>,Double> totalCostAbove1000 = (x)->x.stream().filter(y->y.getPrice()>1000).mapToDouble(z->z.getPrice()).sum();
		System.out.println(totalCostAbove1000.apply(listOfProd));
	}
	
	public static void electronicCost(List<Product> listOfProd) {
		Function<List<Product>,Double> electronicProdCost = (x)->x.stream().filter(y->"Electronics".equalsIgnoreCase(y.getCategory())).mapToDouble(z->z.getPrice()).sum();
		System.out.println(electronicProdCost.apply(listOfProd));			
	}
	
	public static void electronicGreaterThan1000(List<Product> listOfProd) {
		Function<List<Product>,Double> electronicsGT1000 = (x)->x.stream().filter(y->"Electronics".equalsIgnoreCase(y.getCategory())).filter(z->z.getPrice()>1000).mapToDouble(i->i.getPrice()).sum();
		System.out.println(electronicsGT1000.apply(listOfProd));
	}
	
}
