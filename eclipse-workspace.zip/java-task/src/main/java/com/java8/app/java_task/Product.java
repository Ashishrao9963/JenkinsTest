package com.java8.app.java_task;

public class Product{
	String name;
	double price;
	String category;
	String grade;
	public Product(String name, double price, String category, String grade){
		this.name =  name;
		this.price = price;
		this.category = category;
		this.grade = grade;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	public String toString() {
		return "Name: "+this.name+"\nPrice: "+this.price + "\nCategory: "+this.category+"\ngrade: "+this.grade;
	}
	
	
	
	/*Pre Conditions
	- Define a Product class with name, price, category, grade
	Predicates
	1. Define a predicate to check if the price of given product is greater
	 than 1000/-. Print all the products from the given list of the products
	  if the price is greater than 1000/-. 
	2. Define a predicate to check if the product is of electronics category.
	 Print all the products from the given list of the products if the product
	  is of electronics category. 
	3. Print all the products from the given list of product if the product price
	 is greater than 100/- which are in electronics category.
	4. Print all the products from the given list of product if the product price
	 is greater than 100/- or product is in electronics category.
	5. Print all the products from the given list of product if the product price
	 is less than 100/- and product is in electronics category.
	*/
}
