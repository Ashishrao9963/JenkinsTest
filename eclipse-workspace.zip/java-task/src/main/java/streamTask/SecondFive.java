package streamTask;

import java.util.*;
import java.util.stream.Collectors;

public class SecondFive {
	
//	6.	Count the number of employees in each department?
//	7.	What is the average salary of each department?
//	8.	Get the details of youngest male employee in the product development department?
//	9.	Who has the most working experience in the organization?
//	10.	How many male and female employees are there in the sales and marketing team?
	
	public static void noOfEmpByDep(List<Employee> empList) {
		System.out.println(empList.stream().collect(Collectors.groupingBy(x->x.getDepartment(),Collectors.counting())));
	}
	
	public static void avgSalByDep(List<Employee> empList) {
		System.out.println(empList.stream().collect(Collectors.groupingBy(x->x.getDepartment(),Collectors.averagingDouble(y->y.getSalary()))));
	}
	
	public static void youngestMale(List<Employee> empList) {
		int lowestAge = empList.stream().mapToInt(x->x.getAge()).min().getAsInt();
		empList.stream().filter(x->x.getAge()==lowestAge).forEach(System.out::println);
	}
	
	public static void mostExperience(List<Employee> empList) {
		int minYOJ = empList.stream().mapToInt(x->x.getYearOfJoining()).min().getAsInt();
		empList.stream().filter(x->x.getYearOfJoining()==minYOJ).forEach(System.out::println);
	}
	
	public static void maleFemaleInSales(List<Employee> empList) {
		long femaleInSales = empList.stream().filter(x->"Sales And Marketing".equalsIgnoreCase(x.getDepartment())).filter(y->"female".equalsIgnoreCase(y.getGender())).count();
		long maleInSales = empList.stream().filter(x->"Sales And Marketing".equalsIgnoreCase(x.getDepartment())).filter(y->"male".equalsIgnoreCase(y.getGender())).count();
		System.out.println("Men in Sales: "+ maleInSales + "  Women in sales: "+ femaleInSales);
	}
	
	
}
