package streamTask;

import java.util.*;
import java.util.stream.Collectors;

public class LastFive {
	
//	11.	What is the average salary of male and female employees?
//	12.	List down the names of all employees in each department?
//	13.	What is the average salary and total salary of the whole organization?
//	14.	Separate the employees who are younger or equal to 25 years
	//from those employees who are older than 25 years.
//	15.	Who is the oldest employee in the organization? What is his age and 
	//which department he belongs to?

	public static void avgSalMaleFemale(List<Employee> empList) {
		double femaleAvgSal = empList.stream().filter(x->"Female".equalsIgnoreCase(x.getGender())).collect(Collectors.averagingDouble(x->x.getSalary()));
		double maleAvgSal = empList.stream().filter(x->"Male".equalsIgnoreCase(x.getGender())).collect(Collectors.averagingDouble(x->x.getSalary()));
		System.out.println("Male avg sal: " + maleAvgSal + "  Female avg sal: " + femaleAvgSal);
	}
	
	public static void employeesInEachDep(List<Employee> empList) {
		System.out.println(empList.stream().collect(Collectors.groupingBy(Employee::getDepartment,Collectors.mapping(Employee::getName,Collectors.toList()))));
	}
	
	public static void avgSalAndTotSal(List<Employee> empList) {
		double totSal = empList.stream().mapToDouble(x->x.getSalary()).sum();
		int sizeOfList = empList.size();
		System.out.println("Total sal: "+ totSal);
		System.out.println("Avg sal: " + totSal/sizeOfList);
	}
	
	public static void youngerThanOrEqualTo25(List<Employee> empList) {
		empList.stream().filter(x->x.getAge()<=25).forEach(x->System.out.println(x));
	}
	
	public static void oldestEmployee(List<Employee> empList) {
		Optional<Employee> oldestEmp = empList.stream().max(Comparator.comparingInt(Employee::getAge));
        oldestEmp.ifPresent(emp -> System.out.println("Oldest employee: " + emp.getName() + "  Age: " + emp.getAge() + " Department: " + emp.getDepartment()));
	}
	
	
}
