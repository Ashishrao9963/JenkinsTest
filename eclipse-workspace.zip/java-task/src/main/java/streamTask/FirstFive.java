package streamTask;

import java.util.*;
import java.util.stream.Collectors;

public class FirstFive {
//	1.	How many male and female employees are there in the organization?
//	2.	Print the name of all departments in the organization?
//	3.	What is the average age of male and female employees?
//	4.	Get the details of highest paid employee in the organization?
//	5.	Get the names of all employees who have joined after 2015?
	static long maleCount,femaleCount;
	public static void maleAndFemale(List<Employee> empList) {
		 maleCount = empList.stream().filter((x)->"Male".equalsIgnoreCase(x.getGender())).count();
		femaleCount = empList.stream().filter((x)->"Female".equalsIgnoreCase(x.getGender())).count();
		System.out.println("Men in the org.: " + maleCount + "Female in the org.: " + femaleCount);
		
	}
	
	public static void departments(List<Employee> empList) {
		empList.stream().map(x->x.getDepartment()).distinct().forEach(y->System.out.println(y));
		
	}
	
	public static void avgAgeMaleFemale(List<Employee> empList) {
		double avgMaleAge = empList.stream().filter(x ->"Male".equalsIgnoreCase(x.getGender())).collect(Collectors.averagingInt(y->y.getAge()));
		double avgFemaleAge = empList.stream().filter(x ->"Female".equalsIgnoreCase(x.getGender())).collect(Collectors.averagingInt(y->y.getAge()));
		System.out.println("Avg male age: "+ avgMaleAge + "Avg female age: " + avgFemaleAge);
	}
	
	public static void highestPaidEmp(List<Employee> empList) {
		double sal = empList.stream().mapToDouble(x->x.getSalary()).max().orElse(0);
		empList.stream().filter(x -> sal == (x.getSalary())).forEach(y->System.out.println(y));
		
	}
	
	public static void joinedAfter2015(List<Employee> empList) {
		empList.stream().filter(x -> x.getYearOfJoining() > 2015).forEach(System.out::println);
	}
	
	
	
	
	
	
	
	
	
}