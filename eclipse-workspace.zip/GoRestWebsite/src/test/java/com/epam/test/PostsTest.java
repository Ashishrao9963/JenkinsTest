package com.epam.test;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.epam.data.PostsDataProvider;
import com.epam.pojo.PostsPojo;
import com.epam.service.PostsService;

public class PostsTest {
	
	PostsService postsService;
	 
	@BeforeTest
	public void setPosts() {
		postsService = new PostsService();
	}
	
	@Test(dataProviderClass=PostsDataProvider.class,dataProvider = "verifyBody")
	public void verifyGettingPostsById(String id,PostsPojo expectedBody) {
		Assert.assertEquals(postsService.getPostByResponse(id),expectedBody);
	}
	
	@Test(dataProviderClass=PostsDataProvider.class,dataProvider = "idValuesForPosts")
	public void verifyStatusCodes(String id) {
		Assert.assertEquals(postsService.getStatusCodes(id),200);
	}
	
	@Test
	public void verifyNoOfPosts() {
		Assert.assertEquals(postsService.getNoOfPosts(), 10);
	}
}