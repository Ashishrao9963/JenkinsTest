package com.epam.service;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;

import com.epam.pojo.PostsPojo;

import io.restassured.http.Method;
import io.restassured.response.Response;

public class PostsService {
	
	public Response getPostsResponse(String id){
    	baseURI = "https://gorest.co.in/public/v2/posts/";
        return given().log().all().request(Method.GET,id);
    }
	
	public PostsPojo getPostByResponse(String id) {
		Response postResponse = getPostsResponse(id);
		return postResponse.as(PostsPojo.class);
	}
	
	public int getStatusCodes(String id){
        Response postsResponse = getPostsResponse(id);
        int statusCode = postsResponse.getStatusCode();
        return statusCode;
    }
	
	public int getNoOfPosts() {
		baseURI = "https://gorest.co.in/public/v2/posts";
		return given().log().all().request(Method.GET).as(ArrayList.class).size();
	}
}