package com.epam.pojo;

public record PostsPojo(String id,String user_id,String title, String body) {

}
