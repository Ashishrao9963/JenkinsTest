package com.epam.data;

import org.testng.annotations.DataProvider;

import com.epam.pojo.PostsPojo;

public class PostsDataProvider {
	
	@DataProvider(name="idValuesForPosts")
	public Object[][] idValuesForPosts(){
		return new Object[][] {
			{"102605"},
			{"102603"},
			{"102600"},
			{"102594"},
			{"102590"}
		};
	}
	
	@DataProvider(name="verifyBody")
	public Object[][] verifyBody(){
		return new Object[][]{
			{"102605",new PostsPojo("102605","6371370","Depono cunabula sortitus colloco aggero claudeo.","Arca cubo brevis. Ustilo unde pel. Vitae recusandae ulterius. Cavus theatrum vallum. Vinitor arbitro decretum. Sunt spiculum tam. Stillicidium denego tremo. Colligo adnuo arguo. Aut sordeo testimonium. Articulus temeritas perspiciatis. Ea ascisco veritas. Correptius addo creptio. Repellat dolorem est.")},
			{"102603",new PostsPojo("102603","6371369","Comminor beatus voluptatem quam vaco dolorum.","Debeo clam custodia. Suspendo dolore iste. Infit xiphias cumque. Et vix cometes. Demum assentator cuius. Armarium nobis curo. Bellicus comburo uberrime. Timor cibus depromo. Aer ea caries. Solus vinum allatus. Aequitas territo numquam. Vel casus crur. Tonsor cimentarius crustulum. Inflammatio conspergo despecto. Sint uxor debitis. Facere amplus venia. Sum qui bestia. Varietas credo atque. Vel summisse degero.")},
			{"102600",new PostsPojo("102600","6371366","Curriculum sui crebro solutio antea cultellus unus adsidue.","Ab summopere accipio. Quia ocer blanditiis. Concido cogo creta. Ter aggero certus. Creator cerno acidus. Stipes sufficio vester. Calamitas aureus condico. Solio et tum. Eum universe amita. Suspendo aestas amor. Considero deleniti ventus. Degusto dedico odio. Capio voluptatem atrocitas. Corrupti textus non.")},
			{"102594",new PostsPojo("102594","6371361","Confugo vicinus contabesco admoneo quibusdam eligendi tibi titulus bos.","Tantum cetera terebro. Circumvenio taceo vomer. Amaritudo cavus tondeo. Spero varius sed. Cupiditate callide amplitudo. Commodi uredo verumtamen. Tredecim candidus titulus. Clam adipisci pauci. Viduata depromo somniculosus. Desolo balbus utor. Tenax vultuosus baiulus. Suspendo depono undique. Avaritia dolor dens. Blanditiis arx cruentus. Turbo sed adeo. Attero adinventitias accommodo.")},
			{"102590",new PostsPojo("102590","6371358","Aeneus nemo tumultus cruentus desipio.","Abduco minus asperiores. Cohaero spiritus aer. Clamo concedo conqueror. Pauci pecto arx. Bestia textus ceno. Conduco sunt vado. Pecto ulciscor peccatus. Volutabrum aggero sed. Verecundia tersus tepesco. Denique abeo subnecto. Credo tamquam callide. Voluptatem aeternus quas. Anser ventosus pecto. Venia tunc communis. Nisi caterva armo.")}
		};
	}
}