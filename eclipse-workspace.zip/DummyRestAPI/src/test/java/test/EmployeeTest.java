package test;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pojo.EmployeeRecord;
import service.EmployeeService;

public class EmployeeTest {
	
	EmployeeService employeeService;
	
	@BeforeTest
	public void setEmployeeService() {
		employeeService = new EmployeeService();
	}
	
	@Test
	public void verifyNoOfEmployees() {
		Assert.assertEquals(employeeService.noOfEmployees(),24);
	}
	
	
	@Test
	public void verifyCreationStatusCode() {
		Assert.assertEquals(employeeService.getCreationStatusCode(new EmployeeRecord("25","Shiva Nath","22000","21","")),201);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}