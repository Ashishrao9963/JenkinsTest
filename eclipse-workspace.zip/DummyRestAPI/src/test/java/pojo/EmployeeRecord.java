package pojo;

public record EmployeeRecord(String id,String employee_name, String employee_salary,String employee_age,String profile_image) {
	
}