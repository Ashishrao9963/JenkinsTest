package service;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import io.restassured.http.Method;
import io.restassured.response.Response;
import pojo.EmployeeRecord;

public class EmployeeService {
	
	public Response getEmployees() {
		baseURI = "https://dummy.restapiexample.com/api/v1/employees";
		return given().request(Method.GET);
	}
	
	public int noOfEmployees() {
		baseURI = "https://dummy.restapiexample.com/api/v1/employees";
		return given().request(Method.GET).jsonPath().getList("data").size();
	}
	
//	a. verify that employee is created successfully.
//  b. verify the count of employees is increased by +1
	
	public Response createEmployee(EmployeeRecord employee) {
		baseURI = "https://dummy.restapiexample.com/api/v1/employees";
		return given().body(employee).request(Method.POST);
	}
	
	public int getCreationStatusCode(EmployeeRecord employee) {
		createEmployee(employee).prettyPrint();
		return createEmployee(employee).getStatusCode();
	}
	
	public String getCreationStatusLine(EmployeeRecord employee) {
		System.out.println(createEmployee(employee).getStatusLine());
		return createEmployee(employee).getStatusLine();
	}
	
	public String getCreationContentType(EmployeeRecord employee) {
		System.out.println(createEmployee(employee).getContentType());
		return createEmployee(employee).getContentType();
	}
	
	
	
	
}