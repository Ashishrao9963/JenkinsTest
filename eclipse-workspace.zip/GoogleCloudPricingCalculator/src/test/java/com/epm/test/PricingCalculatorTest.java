package com.epm.test;

import static constants.Constants.GOOGLE_CLOUD_URL;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.epm.webdriver.WebDriverSingleton;

import pages.CalculatorPage;
import pages.GoogleCloudPage;
import pages.SearchResultsPage;

public class PricingCalculatorTest {
	
	WebDriverSingleton webDriverSingleton = new WebDriverSingleton();
	WebDriver driver;
	GoogleCloudPage googleCloudPage;
	SearchResultsPage searchResultsPage;
	CalculatorPage calculatorPage;
	
	@BeforeTest(alwaysRun = true)
	private void setWebDriver() {
		this.driver = webDriverSingleton.getWebDriver("chromedriver");
	}
	
	private void navigateToGoogleCloud() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
	}
	
	@Test
	public void verifyOpeningOfUrl() {
		navigateToGoogleCloud();
		Assert.assertEquals(driver.findElement(By.xpath("//h1/p")).getText(),"The new way to cloud starts here");
	}
	
	@Test
	public void verifySearchButtonPresence() {
		navigateToGoogleCloud();
		googleCloudPage = new GoogleCloudPage(driver);
		Assert.assertTrue(googleCloudPage.searchButton.isDisplayed());
	}
	
	@Test
	public void verifySearchButtonFunctionality() {
		googleCloudPage = new GoogleCloudPage(driver);
		googleCloudPage.clickSearchButton();
		Assert.assertTrue(googleCloudPage.searchBar.isDisplayed());
	}
	
	@Test
	public void verifySearchResults() {
		googleCloudPage = new GoogleCloudPage(driver);
		searchResultsPage = googleCloudPage.searchResults();
		Assert.assertTrue(searchResultsPage.legacyCalculatorLink.isDisplayed());
	}
	
	@Test
	public void verifyCalculatorPageIsDisplayed() {
		googleCloudPage = new GoogleCloudPage(driver);
		searchResultsPage = googleCloudPage.searchResults();
		calculatorPage = new CalculatorPage(driver);
		calculatorPage.clickComputeEngine(searchResultsPage);
		Assert.assertTrue(calculatorPage.computeEngine.isDisplayed());
	}
	
	@Test
	public void verifyNumberOfInstances() {
		calculatorPage = new CalculatorPage(driver);
		calculatorPage.enterNumberOfInstances();
		Assert.assertEquals(calculatorPage.noOfInstances.getAttribute("value"),"12");
	}
	
	@Test
	public void verifyOperatingSystem() {
		calculatorPage = new CalculatorPage(driver);
		calculatorPage.selectOperatingSystem();
		Assert.assertTrue(calculatorPage.operatingSystemToSelect.isDisplayed());
	}
	
	@Test
	public void verifyProvisionalModel() {
		calculatorPage = new CalculatorPage(driver);
		calculatorPage.selectProvisionalModel();
		Assert.assertTrue(calculatorPage.provisionalModelToSelect.isDisplayed());
	}
	
	@Test
	public void verifyMachineType() {
		calculatorPage = new CalculatorPage(driver);
		calculatorPage.selectMachineType();
		Assert.assertTrue(calculatorPage.machineTypeToSelect.isDisplayed());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Test (enabled = false)
	public void verifyUrl() throws InterruptedException {
		navigateToGoogleCloud();
		driver.manage().window().maximize();
		
		googleCloudPage = new GoogleCloudPage(driver);
		googleCloudPage.clickSearchButton();
		
		
		
		driver.findElement(By.xpath("//input[@class='qdOxv-fmcmS-wGMbrd']")).sendKeys("Google Cloud Pricing Calculator");
		driver.findElement(By.xpath("//input[@class='qdOxv-fmcmS-wGMbrd']")).sendKeys(Keys.RETURN);
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@track-type='search-result' and @track-metadata-eventdetail='cloud.google.com/products/calculator-legacy']")));
		
		driver.findElement(By.xpath("//a[@track-type='search-result' and @track-metadata-eventdetail='cloud.google.com/products/calculator-legacy']")).click();
		
	}
	
}