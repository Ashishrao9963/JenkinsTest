package stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java8.En;

public class StepDefinitions implements En{
	
	WebDriver driver;
	
	public final String SELENIUM_HOME = "https://www.selenium.dev/";
	public final String DOCUMENTATION = "Documentation";
	
	public StepDefinitions() {
		
		Given("^I open the Selenium home page$",()->{
			driver = new ChromeDriver();
			driver.get(SELENIUM_HOME);
		});
		
		When("^I click the documentation link$", ()->{
			driver.findElement(By.linkText(DOCUMENTATION)).click();
		});
		
		Then("^Documentation page should be opened$", ()->{
			Assert.assertTrue(driver.getCurrentUrl().contains("Documentation"));
		});
		
	}
	
}