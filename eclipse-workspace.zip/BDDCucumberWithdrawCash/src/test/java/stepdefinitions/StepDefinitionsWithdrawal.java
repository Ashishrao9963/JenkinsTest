package stepdefinitions;



import io.cucumber.java8.En;
import org.junit.Assert;

public class StepDefinitionsWithdrawal implements En {

    private int balance;
    private int money;

    public StepDefinitionsWithdrawal() {
        Given("^I have a balance of \\$(\\d+) in my account$", (Integer balance) -> {
            this.balance = balance;
        });

        When("^I request \\$(\\d+)$", (Integer request) -> {
            if( balance >= request ) {
                money = request;
                balance = balance - request;
            } else {
                money = 0;
            }
        });

        Then("^\\$(\\d+) should be dispensed$", (Integer dispensed) -> {
            Assert.assertEquals(dispensed.intValue(), money);
        });
    }
}
