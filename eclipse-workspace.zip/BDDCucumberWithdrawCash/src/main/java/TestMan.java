import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestMan {
    public static void main(String[] args) {
        ArrayList<Integer> arl = new ArrayList<>();
        arl.add(1);
        arl.add(2);
        arl.add(3);
        arl.add(4);
        arl.add(5);
        arl.add(6);
        arl.add(7);
        arl.add(8);
        arl.add(9);
        List<Integer> stream = arl.stream().filter(x -> (arl.indexOf(x))%2==0).collect(Collectors.toList());
        System.out.println(stream);
    }
}
