package apitesting;

import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PetStore {
	
	@Test
	public void verifyPostOperationsStoreInformation() {
		//RestAssured.baseURI="https://petstore.swagger.io/v2/";
		//RestAssured.basePath="store/order";
		
		/*
		 * String storeOrderJson ="{\r\n" + "  \"id\": 1234,\r\n" +
		 * "  \"petId\": 35,\r\n" + "  \"quantity\": 100,\r\n" +
		 * "  \"shipDate\": \"2024-02-13T11:35:13.246+0000\",\r\n" +
		 * "  \"status\": \"placed\",\r\n" + "  \"complete\": true\r\n" + "}";
		 * System.out.println(storeOrderJson);
		 */
		 
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("id", 12345);
		jsonObject.put("petId", 432);
		jsonObject.put("quantity", 12);
		jsonObject.put("shipDate", "2023-07-10T17:34:02.982+0000");
		jsonObject.put("status", "approved");
		jsonObject.put("complete", true);
		
			 
		
		RequestSpecification request= RestAssured.given()
				.header("Content-Type", "application/json");
				
				Response response= request.body(jsonObject.toString())
				.request(Method.POST, "https://petstore.swagger.io/v2/store/order");
		System.out.println(response.asPrettyString()+ response.getStatusCode());
		
	}

}
