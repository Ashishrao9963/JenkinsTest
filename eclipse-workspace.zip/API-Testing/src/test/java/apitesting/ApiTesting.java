package apitesting;

import static org.testng.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ApiTesting {
	
	@Test
	public void getPetById() {
		RestAssured.baseURI = "http://petstore.swagger.io/";
		RequestSpecification httpRequest = RestAssured.given();
		Response httpResponse = httpRequest.request(Method.GET, "/v2/pet/1");
		System.out.println(httpResponse.getStatusCode());
//		Assert.assertEquals(httpResponse.getStatusCode(), 200);
		System.out.println(httpResponse.getStatusLine());
		
		Map hashMap = httpResponse.as(HashMap.class);
		System.out.println(hashMap.get("id"));
		System.out.println(hashMap.get("category"));
		System.out.println(hashMap.get("name"));
		System.out.println(hashMap.get("status"));
		
		JsonPath jsonPath = httpResponse.jsonPath();
		System.out.println(jsonPath.get("id"));
		System.out.println(jsonPath.get("category"));
		System.out.println(jsonPath.get("name"));
		System.out.println(jsonPath.get("status"));
	}
	@Test
	public void postPet() {
		RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
		RequestSpecification httpRequestForPost = RestAssured.given();
		String addPet = "{\n" +
	            "  \"id\": 12,\n" +
	            "  \"category\": {\n" +
	            "    \"id\": 1,\n" +
	            "    \"name\": \"sample\"\n" +
	            "  },\n" +
	            "  \"name\": \"freddie\",\n" +
	            "  \"photoUrls\": [\n" +
	            "    \"string\"\n" +
	            "  ],\n" +
	            "  \"tags\": [\n" +
	            "    {\n" +
	            "      \"id\": 0,\n" +
	            "      \"name\": \"string\"\n" +
	            "    }\n" +
	            "  ],\n" +
	            "  \"status\": \"pending\"\n" +
	            "}";
		
		Response responseForPost = httpRequestForPost.header("Content-type","application/json").body(addPet).request(Method.POST);
//		Response httpResponseForPost = httpRequestForPost./(Method.POST,"/v2/pet");
		responseForPost.prettyPrint();
		//Assert.assertEquals(responseForPost.getStatusCode(),201);
		System.out.println(responseForPost.getStatusLine());
		
		
	}
	
	@Test
	public void testPetStoreDetails(){
	    String json = "{\n" +
	            "  \"id\": 12,\n" +
	            "  \"category\": {\n" +
	            "    \"id\": 1,\n" +
	            "    \"name\": \"sample\"\n" +
	            "  },\n" +
	            "  \"name\": \"freddie\",\n" +
	            "  \"photoUrls\": [\n" +
	            "    \"string\"\n" +
	            "  ],\n" +
	            "  \"tags\": [\n" +
	            "    {\n" +
	            "      \"id\": 0,\n" +
	            "      \"name\": \"string\"\n" +
	            "    }\n" +
	            "  ],\n" +
	            "  \"status\": \"pending\"\n" +
	            "}";
	    RequestSpecification requestSpecification = RestAssured.given();
	    requestSpecification.header("content-type", "application/json");
	    RequestSpecification body = requestSpecification.body(json);
	    Response response=requestSpecification.request(Method.POST,"https://petstore.swagger.io/v2/pet");
	    System.out.println(response.getStatusLine());
	    response.prettyPrint();
	}
	
	
	@Test
	public void jsonObjectImpl() {
		
		JSONObject categoryJson = new JSONObject();
		categoryJson.put("id", 1234);
		categoryJson.put("name", "Shivanath");
		
		String[] photoUrlArray = {"string"};
		
		JSONArray tagsJson = new JSONArray();
		
		JSONObject tagObj = new JSONObject();
		tagObj.put("id", 99);
		tagObj.put("name", "Some Tag name");
		
		tagsJson.put(tagObj);
		
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("id", 1111);
		jsonObj.put("category", categoryJson);
		jsonObj.put("name", "babydog");
		jsonObj.put("photoUrls", photoUrlArray);
		jsonObj.put("tags", tagsJson);
		jsonObj.put("status", "unavailable");
		
//		JSONObject category = new JSONObject();
//	    category.put("id","345");
//	    category.put("name","Test");
//	    JSONObject json = new JSONObject();
//	    json.put("id", "123");
//	    json.put("name", "Sample Test Freddie");
//	    json.put("photoUrls",   "http://petstore.swagger.io/v2/");
//	    json.put("tags",   "[{\"id\": 0, \"name\": \"string\"}]");
//	    json.put("status", "sold");
//	    json.put("categories", category );
//	    					   https://petstore.swagger.io/v2/pet
		RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
		RequestSpecification requestSpecification = RestAssured.given();
		Response response = requestSpecification.header("content-type","application/json").body(jsonObj).request(Method.POST);
		response.prettyPrint();
//		assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void testPostWithCustomObj(){
	    JSONObject category = new JSONObject();
	    category.put("id","345");
	    category.put("name","Test");
	    JSONObject json = new JSONObject();
	    json.put("id", "123");
	    json.put("name", "Sample Test Freddie");
	    json.put("photoUrls",   "http://petstore.swagger.io/v2/");
	    json.put("tags",   "[{\"id\": 0, \"name\": \"string\"}]");
	    json.put("status", "sold");
	    json.put("categories", category );
	    RequestSpecification requestSpecification = RestAssured.given();
	    requestSpecification.header("content-type", "application/json");
	    RequestSpecification body = requestSpecification.body(json);
	    Response response=requestSpecification.request(Method.POST,"https://petstore.swagger.io/v2/pet");
	    System.out.println(response.getStatusLine());
	    response.prettyPrint();
	}
}