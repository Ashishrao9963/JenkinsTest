package constants;

public class Constants {
	
	public static final String GOOGLE_CLOUD_URL = "https://cloud.google.com/?hl=en";
	
	
	
}