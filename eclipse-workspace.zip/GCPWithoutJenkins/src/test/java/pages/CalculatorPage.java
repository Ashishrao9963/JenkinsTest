package pages;

import static constants.Constants.GOOGLE_CLOUD_URL;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CalculatorPage {

	WebDriver driver;

	public CalculatorPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//iframe[@src='https://cloud.google.com/frame/products/calculator-legacy/index_d6a98ba38837346d20babc06ff2153b68c2990fa24322fe52c5f83ec3a78c6a0.frame']")
	public WebElement outerFrame;

	public void switchToOuterFrame() {
		driver.switchTo().frame(outerFrame);
	}

	@FindBy(xpath = "//iframe[@id=\"myFrame\"]")
	public WebElement innerFrame;

	public void switchToInnerFrame() {
		driver.switchTo().frame(innerFrame);
	}

	@FindBy(xpath = "//*[@id='tab-item-1']/div/div")
	public WebElement computeEngine;

	public void clickComputeEngine() {
		computeEngine.click();
	}

	@FindBy(xpath = "//input[@name='quantity' and @ng-model='listingCtrl.computeServer.quantity']")
	public WebElement noOfInstances;

	public void enterNoOfInstances() {
		noOfInstances.click();
		noOfInstances.sendKeys("12");
		noOfInstances.sendKeys(Keys.RETURN);
	}

	@FindBy(xpath = "//*[@id='select_value_label_92']")
	public WebElement operatingSystem;

	@FindBy(xpath = "//*[@id='select_option_102']/div[1]")
	public WebElement operatingSystemToSelect;

	public void clickComputeEngine(SearchResultsPage searchResultsPage) {
		CalculatorPage calculatorPage = searchResultsPage.clickLegacyCalculatorLink();
		calculatorPage.switchToOuterFrame();
		calculatorPage.switchToInnerFrame();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(calculatorPage.computeEngine));
	}

	public void enterNumberOfInstances() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
		GoogleCloudPage googleCloudPage = new GoogleCloudPage(driver);
		SearchResultsPage searchResultsPage = googleCloudPage.enterSearchKeyword("Google Pricing Calculator");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultsPage.legacyCalculatorLink));
		CalculatorPage calculatorPage = searchResultsPage.clickLegacyCalculatorLink();
		switchToOuterFrame();
		switchToInnerFrame();
		wait.until(ExpectedConditions.elementToBeClickable(calculatorPage.noOfInstances));
		calculatorPage.enterNoOfInstances();
	}

	public void selectOperatingSystem() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
		GoogleCloudPage googleCloudPage = new GoogleCloudPage(driver);
		SearchResultsPage searchResultsPage = googleCloudPage.enterSearchKeyword("Google Pricing Calculator");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultsPage.legacyCalculatorLink));
		CalculatorPage calculatorPage = searchResultsPage.clickLegacyCalculatorLink();
		switchToOuterFrame();
		switchToInnerFrame();
		wait.until(ExpectedConditions.elementToBeClickable(calculatorPage.operatingSystem));
		operatingSystem.click();
		operatingSystemToSelect.click();
	}

	@FindBy(xpath = "//*[@id='select_value_label_93']")
	public WebElement provisionalModel;

	@FindBy(xpath = "//*[@id='select_option_115']")
	public WebElement provisionalModelToSelect;
	
	public void openPricingCalculator() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
		GoogleCloudPage googleCloudPage = new GoogleCloudPage(driver);
		SearchResultsPage searchResultsPage = googleCloudPage.enterSearchKeyword("Google Pricing Calculator");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultsPage.legacyCalculatorLink));
		searchResultsPage.clickLegacyCalculatorLink();
		switchToOuterFrame();
		switchToInnerFrame();
	}
	
	public void selectProvisionalModel() {
		openPricingCalculator();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(provisionalModel));
		provisionalModel.click();
		provisionalModelToSelect.click();
	}
	
	@FindBy(xpath = "//*[@id='select_value_label_96']")
	public WebElement machineType;
	
	@FindBy(xpath = "//*[@id='select_value_label_96']/span[1]/div")
	public WebElement machineTypeToSelect;
	
	public void selectMachineType() {
		openPricingCalculator();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(machineType));
		machineType.click();
		machineType.click();
	}
	
	
	
	
	
	
	
}