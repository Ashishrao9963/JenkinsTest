package pages;

import static constants.Constants.GOOGLE_CLOUD_URL;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleCloudPage {
	WebDriver driver;

	public GoogleCloudPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='YSM5S' and @jsname='Ohx1pb']")
	public WebElement searchButton;

	public void clickSearchButton() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
		try {
			searchButton.click();
		} catch (Exception e) {
			System.out.println("Exceptions caught: " + e.getMessage());
		}
	}

	@FindBy(xpath = "//input[@jsname='YPqjbf']")
	public WebElement searchBar;

	public SearchResultsPage enterSearchKeyword(String searchKeyword) {
		clickSearchButton();
		searchBar.sendKeys(searchKeyword);
		searchBar.sendKeys(Keys.RETURN);
		return new SearchResultsPage(driver);
	}

	public SearchResultsPage searchResults() {
		driver.navigate().to(GOOGLE_CLOUD_URL);
		SearchResultsPage searchResultsPage = enterSearchKeyword("Google Pricing Calculator");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultsPage.legacyCalculatorLink));
		return new SearchResultsPage(driver);
	}

}