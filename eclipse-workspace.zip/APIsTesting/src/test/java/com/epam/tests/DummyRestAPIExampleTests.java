package com.epam.tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class DummyRestAPIExampleTests {
	RequestSpecification restAssured;
    @BeforeClass
    public RequestSpecification setUp {
        restAssured = RestAssured.given();
    }

    @Test
    public void verifyGetEmployees {
        restAssured.get().then().statusCode(200);
    }

}
