package com.epam.pojos;

import java.util.List;

public class DummyRestAPIExample {
	private String status;
    private List<DummyRestAPIExampleData> data;
}
